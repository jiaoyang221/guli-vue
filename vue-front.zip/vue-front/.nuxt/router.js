import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _6b506d2c = () => interopDefault(import('..\\pages\\course\\index.vue' /* webpackChunkName: "pages_course_index" */))
const _01a927be = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages_login" */))
const _0218f05e = () => interopDefault(import('..\\pages\\register.vue' /* webpackChunkName: "pages_register" */))
const _67a12c2b = () => interopDefault(import('..\\pages\\teacher\\index.vue' /* webpackChunkName: "pages_teacher_index" */))
const _efa06ad8 = () => interopDefault(import('..\\pages\\course\\_id.vue' /* webpackChunkName: "pages_course__id" */))
const _6766756b = () => interopDefault(import('..\\pages\\orders\\_oid.vue' /* webpackChunkName: "pages_orders__oid" */))
const _9156596e = () => interopDefault(import('..\\pages\\pay\\_pid.vue' /* webpackChunkName: "pages_pay__pid" */))
const _b84efda4 = () => interopDefault(import('..\\pages\\player\\_vid.vue' /* webpackChunkName: "pages_player__vid" */))
const _795b855a = () => interopDefault(import('..\\pages\\teacher\\_id.vue' /* webpackChunkName: "pages_teacher__id" */))
const _380184a7 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/course",
    component: _6b506d2c,
    name: "course"
  }, {
    path: "/login",
    component: _01a927be,
    name: "login"
  }, {
    path: "/register",
    component: _0218f05e,
    name: "register"
  }, {
    path: "/teacher",
    component: _67a12c2b,
    name: "teacher"
  }, {
    path: "/course/:id",
    component: _efa06ad8,
    name: "course-id"
  }, {
    path: "/orders/:oid?",
    component: _6766756b,
    name: "orders-oid"
  }, {
    path: "/pay/:pid?",
    component: _9156596e,
    name: "pay-pid"
  }, {
    path: "/player/:vid?",
    component: _b84efda4,
    name: "player-vid"
  }, {
    path: "/teacher/:id",
    component: _795b855a,
    name: "teacher-id"
  }, {
    path: "/",
    component: _380184a7,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
